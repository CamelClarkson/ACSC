$(document).ready(() => {
	const socket = io();
	const timeout = 1500; // ms
	var search_time_out = 0;
	var username = null;
	var in_modal = true;

	// get login info from modal
	$(window).load(() => {
		$('#username_modal').modal('show');
	});

	// once username is submitted close modal
	$('#close_modal').on('click', () => {
		get_username();
		enter_chat_room();
	});

	function get_username() {
		username = $('#username_field').val() !== '' ? $('#username_field').val() : 'anonymous';
		$('#username_field').val('');
	}

	function enter_chat_room() {
		if (username !== null) {
			$('#username_modal').modal('hide');
			in_modal = false;
			socket.emit('init', username);
		}
	}

	// listen for enter keypress (13)
	$(document).keypress((event) => {
		if (event.which === 13) {
			if (in_modal) {
				get_username();
				enter_chat_room();
			} else {
				send_message();
			}
		}
	});

	// listen for send button press
	$('#message_submit').on('click', () => {
		send_message();
	});

	function send_message() {
		var msg = $('#message_field').val();

		if (msg !== '') {
			$('#message_field').val('');

			socket.emit('msg', {
				username: username,
				message: msg,
				admin: false,
			});
		}
	}

	function add_message(data) {
		var $li = data.admin ? $('<li>').append(data.message) : $('<li>').append(data.username + ': ' + data.message);

		$('#messages').append($li);
	}

	// listen for broadcasts
	socket.on('msg', (data) => {
		add_message(data);
	});

});
